package com.nakula.virtualclonestarter;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout cloneBox;
    private LinearLayout appBox;
    private SharedPreferences prefs;
    private PackageManager pm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("clone_slots", MODE_PRIVATE);
        pm = getPackageManager();

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Virtual Clone Starter");
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Versi awal: pilih aplikasi, buat slot clone, dan buka aplikasi asli. Engine virtual penuh ditambahkan tahap berikutnya.");
        info.setTextSize(14);
        info.setPadding(0, dp(8), 0, dp(14));
        root.addView(info);

        TextView cloneTitle = sectionTitle("Slot Clone");
        root.addView(cloneTitle);
        cloneBox = new LinearLayout(this);
        cloneBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(cloneBox);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(8), 0, dp(12));
        Button reload = new Button(this);
        reload.setText("Muat aplikasi");
        reload.setOnClickListener(v -> loadApps());
        actions.addView(reload, new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = new Button(this);
        clear.setText("Hapus slot");
        clear.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            renderClones();
            Toast.makeText(this, "Slot clone dihapus", Toast.LENGTH_SHORT).show();
        });
        actions.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(actions);

        root.addView(sectionTitle("Daftar Aplikasi"));
        appBox = new LinearLayout(this);
        appBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(appBox);

        setContentView(scroll);
        renderClones();
        loadApps();
    }

    private TextView sectionTitle(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(12), 0, dp(8));
        return t;
    }

    private void loadApps() {
        appBox.removeAllViews();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));

        int shown = 0;
        for (ResolveInfo ri : apps) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            String label = ri.loadLabel(pm).toString();
            appBox.addView(appRow(label, pkg, ri));
            shown++;
        }
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("Aplikasi tidak ditemukan.");
            appBox.addView(empty);
        }
    }

    private View appRow(String label, String pkg, ResolveInfo ri) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(ri.loadIcon(pm));
        row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(10), 0, dp(10), 0);
        TextView name = new TextView(this);
        name.setText(label);
        name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        TextView pack = new TextView(this);
        pack.setText(pkg);
        pack.setTextSize(12);
        texts.addView(name);
        texts.addView(pack);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        Button add = new Button(this);
        add.setText("Tambah");
        add.setOnClickListener(v -> addClone(label, pkg));
        row.addView(add);
        return row;
    }

    private void addClone(String label, String pkg) {
        int count = prefs.getInt("count", 0) + 1;
        prefs.edit()
                .putInt("count", count)
                .putString("clone_" + count, label + "||" + pkg)
                .apply();
        renderClones();
        Toast.makeText(this, "Slot dibuat: " + label + " #" + count, Toast.LENGTH_SHORT).show();
    }

    private void renderClones() {
        cloneBox.removeAllViews();
        int count = prefs.getInt("count", 0);
        int shown = 0;
        for (int i = 1; i <= count; i++) {
            String data = prefs.getString("clone_" + i, null);
            if (data == null) continue;
            String[] p = data.split("\\|\\|", 2);
            String label = p.length > 0 ? p[0] : "App";
            String pkg = p.length > 1 ? p[1] : "";
            cloneBox.addView(cloneRow(i, label, pkg));
            shown++;
        }
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada slot clone. Tekan Tambah pada aplikasi di bawah.");
            empty.setPadding(0, dp(4), 0, dp(4));
            cloneBox.addView(empty);
        }
    }

    private View cloneRow(int index, String label, String pkg) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setBackgroundColor(0xFFEFEFEF);

        TextView name = new TextView(this);
        name.setText(String.format(Locale.US, "%s Clone #%d", label, index));
        name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(name);

        TextView pack = new TextView(this);
        pack.setText(pkg);
        pack.setTextSize(12);
        row.addView(pack);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button open = new Button(this);
        open.setText("Buka app asli");
        open.setOnClickListener(v -> openApp(pkg));
        buttons.addView(open, new LinearLayout.LayoutParams(0, -2, 1));
        Button del = new Button(this);
        del.setText("Hapus");
        del.setOnClickListener(v -> {
            prefs.edit().remove("clone_" + index).apply();
            renderClones();
        });
        buttons.addView(del, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(buttons);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(lp);
        return row;
    }

    private void openApp(String pkg) {
        Intent launch = pm.getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Toast.makeText(this, "App tidak bisa dibuka", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(launch);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
EOF

      - name: Build APK
        run: gradle assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
name: VirtualCloneStarter-apk
path: app/build/outputs/apk/debug/*.apk
