plugins {
    id("com.android.application")
}

android {
    namespace = "com.nakula.virtualclonestarter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nakula.virtualclonestarter"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
