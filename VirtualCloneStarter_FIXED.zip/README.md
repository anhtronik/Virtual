# Virtual Clone Starter

Project Android starter untuk membuat daftar aplikasi dan slot clone. Workflow GitHub Actions sudah disiapkan untuk build APK otomatis.

Catatan: ini belum virtual engine penuh seperti Parallel Space. Ini pondasi awal.
